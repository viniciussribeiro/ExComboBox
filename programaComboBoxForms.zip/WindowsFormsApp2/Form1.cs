﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            cboLista.Items.Add(text1.Text);
            text1.Clear();
            text1.Focus();
        }

        private void btnElimi_Click(object sender, EventArgs e)
        {
            if (cboLista.SelectedIndex == -1)
            {
                MessageBox.Show("Nenhum item foi selecionado!!", "Combobox", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                cboLista.Items.RemoveAt(cboLista.SelectedIndex);
            }
        }

        private void btnLimparTudo_Click(object sender, EventArgs e)
        {
            cboLista.Items.Clear();
        }

        private void btn_limpar_Click(object sender, EventArgs e)
        {    
            text1.Clear();
            cboLista.SelectedIndex = -1;
            nmLabPosic.Text = "";
            nmLabSelec.Text = "";
            nmLabTotal.Text = "";
            text1.Focus();
        }

        private void cboLista_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cboLista.SelectedIndex != -1)
            {
                nmLabPosic.Text = cboLista.SelectedIndex.ToString();
                nmLabSelec.Text = cboLista.SelectedItem.ToString();
                nmLabTotal.Text = cboLista.Items.Count.ToString();
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
