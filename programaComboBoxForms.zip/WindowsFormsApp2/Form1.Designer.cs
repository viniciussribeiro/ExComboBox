﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.text1 = new System.Windows.Forms.TextBox();
            this.cboLista = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.nmLabPosic = new System.Windows.Forms.TextBox();
            this.nmLabSelec = new System.Windows.Forms.TextBox();
            this.nmLabTotal = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnElimi = new System.Windows.Forms.Button();
            this.btnLimparTudo = new System.Windows.Forms.Button();
            this.btn_limpar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Digite um texto:";
            // 
            // text1
            // 
            this.text1.Location = new System.Drawing.Point(137, 30);
            this.text1.Name = "text1";
            this.text1.Size = new System.Drawing.Size(587, 20);
            this.text1.TabIndex = 1;
            // 
            // cboLista
            // 
            this.cboLista.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLista.FormattingEnabled = true;
            this.cboLista.Location = new System.Drawing.Point(15, 114);
            this.cboLista.Name = "cboLista";
            this.cboLista.Size = new System.Drawing.Size(709, 21);
            this.cboLista.TabIndex = 2;
            this.cboLista.SelectedIndexChanged += new System.EventHandler(this.cboLista_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(137, 18);
            this.label2.TabIndex = 3;
            this.label2.Text = "Estilo dropdown list";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(34, 192);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Posição na lista: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(34, 216);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Texto selecionado:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(34, 244);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Total de itens:";
            // 
            // nmLabPosic
            // 
            this.nmLabPosic.Location = new System.Drawing.Point(148, 189);
            this.nmLabPosic.Name = "nmLabPosic";
            this.nmLabPosic.ReadOnly = true;
            this.nmLabPosic.Size = new System.Drawing.Size(100, 20);
            this.nmLabPosic.TabIndex = 7;
            // 
            // nmLabSelec
            // 
            this.nmLabSelec.Location = new System.Drawing.Point(148, 216);
            this.nmLabSelec.Name = "nmLabSelec";
            this.nmLabSelec.ReadOnly = true;
            this.nmLabSelec.Size = new System.Drawing.Size(365, 20);
            this.nmLabSelec.TabIndex = 8;
            // 
            // nmLabTotal
            // 
            this.nmLabTotal.Location = new System.Drawing.Point(148, 244);
            this.nmLabTotal.Name = "nmLabTotal";
            this.nmLabTotal.ReadOnly = true;
            this.nmLabTotal.Size = new System.Drawing.Size(100, 20);
            this.nmLabTotal.TabIndex = 9;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(649, 162);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 36);
            this.btnAdd.TabIndex = 10;
            this.btnAdd.Text = "Adicionar";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnElimi
            // 
            this.btnElimi.Location = new System.Drawing.Point(649, 204);
            this.btnElimi.Name = "btnElimi";
            this.btnElimi.Size = new System.Drawing.Size(75, 37);
            this.btnElimi.TabIndex = 11;
            this.btnElimi.Text = "Eliminar";
            this.btnElimi.UseVisualStyleBackColor = true;
            this.btnElimi.Click += new System.EventHandler(this.btnElimi_Click);
            // 
            // btnLimparTudo
            // 
            this.btnLimparTudo.Location = new System.Drawing.Point(649, 247);
            this.btnLimparTudo.Name = "btnLimparTudo";
            this.btnLimparTudo.Size = new System.Drawing.Size(75, 37);
            this.btnLimparTudo.TabIndex = 12;
            this.btnLimparTudo.Text = "Limpar toda a lista";
            this.btnLimparTudo.UseVisualStyleBackColor = true;
            this.btnLimparTudo.Click += new System.EventHandler(this.btnLimparTudo_Click);
            // 
            // btn_limpar
            // 
            this.btn_limpar.Location = new System.Drawing.Point(649, 290);
            this.btn_limpar.Name = "btn_limpar";
            this.btn_limpar.Size = new System.Drawing.Size(75, 37);
            this.btn_limpar.TabIndex = 13;
            this.btn_limpar.Text = "Limpar";
            this.btn_limpar.UseVisualStyleBackColor = true;
            this.btn_limpar.Click += new System.EventHandler(this.btn_limpar_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(649, 333);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(75, 37);
            this.btnSair.TabIndex = 14;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btn_limpar);
            this.Controls.Add(this.btnLimparTudo);
            this.Controls.Add(this.btnElimi);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.nmLabTotal);
            this.Controls.Add(this.nmLabSelec);
            this.Controls.Add(this.nmLabPosic);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cboLista);
            this.Controls.Add(this.text1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Combo Box";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox text1;
        private System.Windows.Forms.ComboBox cboLista;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox nmLabPosic;
        private System.Windows.Forms.TextBox nmLabSelec;
        private System.Windows.Forms.TextBox nmLabTotal;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnElimi;
        private System.Windows.Forms.Button btnLimparTudo;
        private System.Windows.Forms.Button btn_limpar;
        private System.Windows.Forms.Button btnSair;
    }
}

